"use strict";
exports.id = 279;
exports.ids = [279];
exports.modules = {

/***/ 5279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "jY": () => (/* reexport */ logo),
  "qw": () => (/* reexport */ quickcount),
  "Ns": () => (/* reexport */ votebox)
});

;// CONCATENATED MODULE: ./assets/images/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.95360869.png","height":612,"width":812,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAwElEQVR42g3DPQsBcRwH8O/1z4uxkJiwyOOAJAxGk5cgg7wIhMVkMdgUueFyHv6eDZxBSh2XYlFSF/X3+9QHE2GAStUZB3U3+MSjijeoBJCssWcufQ3qKz2PonA/CetlG8hcNVCGyndkyT/6oE35Z4iB+RKB26ZV/FxALajt26y8qoMmutpcdA47kZv1UqWtAsrgXXDmHqugoRhXzPhUNv1jORxZqqAM6fNGinIZ1B5eKc7geuSITIe2pK4hqWvSH78pbeQqeq0+AAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./assets/images/votebox.png
/* harmony default export */ const votebox = ({"src":"/_next/static/media/votebox.bd6429d7.png","height":500,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAt0lEQVR42mOAgSf//7PA2PeR2Aw2DAyMMPbtxvY9d5o6DsH4RSC5////gxWsXbE67s6kaf/vTZ7xf/3SFckMyODggUOhz16+/P/sydO/QPzn+atX/48cPhoLV3DvwcOCf9+/////6dP3f+/ff//39ev/B4+fVCAUPH5S+PfT5/9/nz77//fZ8/9/373//+DZs0q4gtOnzwa9evP2wpsPH/e9+fhx36u3by+cPXsuAiQHcSQmgMsBABh5cm97dlpGAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./assets/images/quickcount.png
/* harmony default export */ const quickcount = ({"src":"/_next/static/media/quickcount.5579165e.png","height":217,"width":438,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAgUlEQVR42mMAgf9MDCU/9dU6GPaukWCAgt02RcwQ1rH/zS+javs+WHDPzZnYu+isD4PN+QQGLpDUuekRLAwMh/5ve5jSPfuVu96a7ClTl+yO09q9Iyq7ZZ/ORFsGBhA49H/Oo+Su9ovxkQdK+yatW1GasHJZRP2hQ7H1Xf//MyQBAGZNNCJ6WjsyAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./assets/index.js






/***/ })

};
;