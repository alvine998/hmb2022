exports.id = 288;
exports.ids = [288];
exports.modules = {

/***/ 1288:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Home_container__bCOhY",
	"main": "Home_main__nLjiQ",
	"footer": "Home_footer____T7K",
	"title": "Home_title__T09hD",
	"description": "Home_description__41Owk",
	"code": "Home_code__suPER",
	"grid": "Home_grid__GxQ85",
	"card": "Home_card___LpL1",
	"logo": "Home_logo__27_tb",
	"inputPosition": "Home_inputPosition__MpUCg",
	"sizeLogo": "Home_sizeLogo__6GAlF",
	"background": "Home_background__I_nYJ",
	"box1": "Home_box1__wKD0u",
	"textbox1": "Home_textbox1__vSMCR",
	"setactive": "Home_setactive__kYRok",
	"textCentering": "Home_textCentering__F3k32",
	"topper": "Home_topper__J_NLY",
	"sider": "Home_sider__pUmOy",
	"boxPemilih": "Home_boxPemilih___VFug",
	"boxKandidat": "Home_boxKandidat__D3hR_",
	"boxSudahPilih": "Home_boxSudahPilih__0jGtP",
	"boxBelumPilih": "Home_boxBelumPilih__2T2RA",
	"toppers": "Home_toppers__ofnKY",
	"whiteText": "Home_whiteText__zy_Mp",
	"uppers": "Home_uppers__4TN7u",
	"righthere": "Home_righthere__235HS",
	"bg": "Home_bg__MDUv5",
	"slide": "Home_slide__DJiuc",
	"bg2": "Home_bg2__YptbV",
	"bg3": "Home_bg3__AcJz3",
	"content": "Home_content__Zy02X",
	"centeringContent": "Home_centeringContent___7nHv",
	"boxPemilihan": "Home_boxPemilihan__GtWJd",
	"boxPemilihan2": "Home_boxPemilihan2__5WpXi",
	"right2": "Home_right2__BRhqI",
	"content2": "Home_content2__fY9rW",
	"boxCalon": "Home_boxCalon__p82cG",
	"sizing": "Home_sizing__9US2V",
	"charts": "Home_charts__Kc9Dd",
	"attractive": "Home_attractive__5vT7J"
};


/***/ })

};
;