import logo from './images/logo.png';
import vote from './images/votebox.png';
import qcount from './images/quickcount.png';

export {
    logo,
    vote,
    qcount
};